package com.andriod.echoofchoices.screen.login

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.andriod.echoofchoices.R
import com.andriod.echoofchoices.screen.utils.getEditTextValue
import com.andriod.echoofchoices.screen.utils.toast
import com.andriod.echoofchoices.app.CustomApp
import com.andriod.echoofchoices.screen.dashboard.DashboardActivity

class LoginActivity : AppCompatActivity(), LoginContact.View {
    lateinit var presenter: LoginPresenter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        presenter = LoginPresenter(this, LoginModel(application as CustomApp))
        (findViewById<Button>(R.id.btnLogin)).setOnClickListener {
            toast("Button login is clicked")
            val username =getEditTextValue(R.id.etEmail)
            val password =getEditTextValue(R.id.etPassword)

            presenter.isValidCredentials(username, password)


        }
    }

    override fun showEmptyMessage() {
        toast("Field cannot be empty")
    }

    override fun showSucuessMessage(){
        toast("Show Sucess Message")
    }

    override fun showDashboardScreen(){
        val intent = Intent(this, DashboardActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun showInvalidCredentials(){
        toast("Show Invalid Message")
    }
}