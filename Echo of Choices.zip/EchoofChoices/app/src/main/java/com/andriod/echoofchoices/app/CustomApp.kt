package com.andriod.echoofchoices.app

import android.app.Application
import android.util.Log
import com.andriod.echoofchoices.data.User

class CustomApp: Application() {

    private val user = User("test","1111")

    override fun onCreate() {
        super.onCreate()

        // Initialtize data database
        // fecth from API or repository data
        // payment setup
        Log.e("Custom App","OnCreate is called")
    }
    fun getUser()= this.user
}